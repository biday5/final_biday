package shop.biday.model.repository;

public interface QUserRepository {
}

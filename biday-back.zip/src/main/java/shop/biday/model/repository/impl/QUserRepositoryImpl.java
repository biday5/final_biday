package shop.biday.model.repository.impl;

public class QUserRepositoryImpl {
}

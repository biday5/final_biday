package shop.biday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BidayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BidayApplication.class, args);
	}

}

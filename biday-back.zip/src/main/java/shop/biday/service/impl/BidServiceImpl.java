package shop.biday.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import shop.biday.service.BidService;

@Service
@RequiredArgsConstructor
public class BidServiceImpl implements BidService {
}

package shop.biday.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import shop.biday.service.WishService;

@Service
@RequiredArgsConstructor
public class WishServiceImpl implements WishService {
}

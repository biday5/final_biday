package shop.biday.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import shop.biday.service.ChatClickService;

@Service
@RequiredArgsConstructor
public class ChatClickServiceImpl implements ChatClickService {
}

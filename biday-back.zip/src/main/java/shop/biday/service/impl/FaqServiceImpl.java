package shop.biday.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import shop.biday.service.FaqService;

@Service
@RequiredArgsConstructor
public class FaqServiceImpl implements FaqService {
}

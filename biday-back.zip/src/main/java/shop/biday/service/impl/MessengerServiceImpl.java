package shop.biday.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import shop.biday.service.MessengerService;

@Service
@RequiredArgsConstructor
public class MessengerServiceImpl implements MessengerService {
}

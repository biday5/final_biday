package shop.biday;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BidayApplicationTests {

	@Test
	void contextLoads() {
	}

}
